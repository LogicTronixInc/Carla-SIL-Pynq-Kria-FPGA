// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xlayer1_depack.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLayer1_depack_CfgInitialize(XLayer1_depack *InstancePtr, XLayer1_depack_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLayer1_depack_Start(XLayer1_depack *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_AP_CTRL) & 0x80;
    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XLayer1_depack_IsDone(XLayer1_depack *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XLayer1_depack_IsIdle(XLayer1_depack *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XLayer1_depack_IsReady(XLayer1_depack *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XLayer1_depack_EnableAutoRestart(XLayer1_depack *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XLayer1_depack_DisableAutoRestart(XLayer1_depack *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_AP_CTRL, 0);
}

void XLayer1_depack_Set_ddr_mem_meta(XLayer1_depack *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_DDR_MEM_META_DATA, (u32)(Data));
    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_DDR_MEM_META_DATA + 4, (u32)(Data >> 32));
}

u64 XLayer1_depack_Get_ddr_mem_meta(XLayer1_depack *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_DDR_MEM_META_DATA);
    Data += (u64)XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_DDR_MEM_META_DATA + 4) << 32;
    return Data;
}

void XLayer1_depack_Set_ddr_mem_points(XLayer1_depack *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_DDR_MEM_POINTS_DATA, (u32)(Data));
    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_DDR_MEM_POINTS_DATA + 4, (u32)(Data >> 32));
}

u64 XLayer1_depack_Get_ddr_mem_points(XLayer1_depack *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_DDR_MEM_POINTS_DATA);
    Data += (u64)XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_DDR_MEM_POINTS_DATA + 4) << 32;
    return Data;
}

void XLayer1_depack_InterruptGlobalEnable(XLayer1_depack *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_GIE, 1);
}

void XLayer1_depack_InterruptGlobalDisable(XLayer1_depack *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_GIE, 0);
}

void XLayer1_depack_InterruptEnable(XLayer1_depack *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_IER);
    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_IER, Register | Mask);
}

void XLayer1_depack_InterruptDisable(XLayer1_depack *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_IER);
    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_IER, Register & (~Mask));
}

void XLayer1_depack_InterruptClear(XLayer1_depack *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer1_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_ISR, Mask);
}

u32 XLayer1_depack_InterruptGetEnabled(XLayer1_depack *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_IER);
}

u32 XLayer1_depack_InterruptGetStatus(XLayer1_depack *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLayer1_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER1_DEPACK_CONTROL_ADDR_ISR);
}

