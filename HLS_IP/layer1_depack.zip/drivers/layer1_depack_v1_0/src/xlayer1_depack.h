// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XLAYER1_DEPACK_H
#define XLAYER1_DEPACK_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xlayer1_depack_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XLayer1_depack_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XLayer1_depack;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XLayer1_depack_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XLayer1_depack_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XLayer1_depack_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XLayer1_depack_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XLayer1_depack_Initialize(XLayer1_depack *InstancePtr, UINTPTR BaseAddress);
XLayer1_depack_Config* XLayer1_depack_LookupConfig(UINTPTR BaseAddress);
#else
int XLayer1_depack_Initialize(XLayer1_depack *InstancePtr, u16 DeviceId);
XLayer1_depack_Config* XLayer1_depack_LookupConfig(u16 DeviceId);
#endif
int XLayer1_depack_CfgInitialize(XLayer1_depack *InstancePtr, XLayer1_depack_Config *ConfigPtr);
#else
int XLayer1_depack_Initialize(XLayer1_depack *InstancePtr, const char* InstanceName);
int XLayer1_depack_Release(XLayer1_depack *InstancePtr);
#endif

void XLayer1_depack_Start(XLayer1_depack *InstancePtr);
u32 XLayer1_depack_IsDone(XLayer1_depack *InstancePtr);
u32 XLayer1_depack_IsIdle(XLayer1_depack *InstancePtr);
u32 XLayer1_depack_IsReady(XLayer1_depack *InstancePtr);
void XLayer1_depack_EnableAutoRestart(XLayer1_depack *InstancePtr);
void XLayer1_depack_DisableAutoRestart(XLayer1_depack *InstancePtr);

void XLayer1_depack_Set_ddr_mem_meta(XLayer1_depack *InstancePtr, u64 Data);
u64 XLayer1_depack_Get_ddr_mem_meta(XLayer1_depack *InstancePtr);
void XLayer1_depack_Set_ddr_mem_points(XLayer1_depack *InstancePtr, u64 Data);
u64 XLayer1_depack_Get_ddr_mem_points(XLayer1_depack *InstancePtr);

void XLayer1_depack_InterruptGlobalEnable(XLayer1_depack *InstancePtr);
void XLayer1_depack_InterruptGlobalDisable(XLayer1_depack *InstancePtr);
void XLayer1_depack_InterruptEnable(XLayer1_depack *InstancePtr, u32 Mask);
void XLayer1_depack_InterruptDisable(XLayer1_depack *InstancePtr, u32 Mask);
void XLayer1_depack_InterruptClear(XLayer1_depack *InstancePtr, u32 Mask);
u32 XLayer1_depack_InterruptGetEnabled(XLayer1_depack *InstancePtr);
u32 XLayer1_depack_InterruptGetStatus(XLayer1_depack *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
