// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xlayer1_depack.h"

extern XLayer1_depack_Config XLayer1_depack_ConfigTable[];

#ifdef SDT
XLayer1_depack_Config *XLayer1_depack_LookupConfig(UINTPTR BaseAddress) {
	XLayer1_depack_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XLayer1_depack_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XLayer1_depack_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XLayer1_depack_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XLayer1_depack_Initialize(XLayer1_depack *InstancePtr, UINTPTR BaseAddress) {
	XLayer1_depack_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XLayer1_depack_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XLayer1_depack_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XLayer1_depack_Config *XLayer1_depack_LookupConfig(u16 DeviceId) {
	XLayer1_depack_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XLAYER1_DEPACK_NUM_INSTANCES; Index++) {
		if (XLayer1_depack_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XLayer1_depack_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XLayer1_depack_Initialize(XLayer1_depack *InstancePtr, u16 DeviceId) {
	XLayer1_depack_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XLayer1_depack_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XLayer1_depack_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

