// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xpacket_dispatcher.h"

extern XPacket_dispatcher_Config XPacket_dispatcher_ConfigTable[];

#ifdef SDT
XPacket_dispatcher_Config *XPacket_dispatcher_LookupConfig(UINTPTR BaseAddress) {
	XPacket_dispatcher_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XPacket_dispatcher_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XPacket_dispatcher_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XPacket_dispatcher_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XPacket_dispatcher_Initialize(XPacket_dispatcher *InstancePtr, UINTPTR BaseAddress) {
	XPacket_dispatcher_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XPacket_dispatcher_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XPacket_dispatcher_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XPacket_dispatcher_Config *XPacket_dispatcher_LookupConfig(u16 DeviceId) {
	XPacket_dispatcher_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XPACKET_DISPATCHER_NUM_INSTANCES; Index++) {
		if (XPacket_dispatcher_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XPacket_dispatcher_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XPacket_dispatcher_Initialize(XPacket_dispatcher *InstancePtr, u16 DeviceId) {
	XPacket_dispatcher_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XPacket_dispatcher_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XPacket_dispatcher_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

