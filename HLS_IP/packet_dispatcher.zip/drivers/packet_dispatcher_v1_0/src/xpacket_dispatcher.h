// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XPACKET_DISPATCHER_H
#define XPACKET_DISPATCHER_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xpacket_dispatcher_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XPacket_dispatcher_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XPacket_dispatcher;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XPacket_dispatcher_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XPacket_dispatcher_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XPacket_dispatcher_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XPacket_dispatcher_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XPacket_dispatcher_Initialize(XPacket_dispatcher *InstancePtr, UINTPTR BaseAddress);
XPacket_dispatcher_Config* XPacket_dispatcher_LookupConfig(UINTPTR BaseAddress);
#else
int XPacket_dispatcher_Initialize(XPacket_dispatcher *InstancePtr, u16 DeviceId);
XPacket_dispatcher_Config* XPacket_dispatcher_LookupConfig(u16 DeviceId);
#endif
int XPacket_dispatcher_CfgInitialize(XPacket_dispatcher *InstancePtr, XPacket_dispatcher_Config *ConfigPtr);
#else
int XPacket_dispatcher_Initialize(XPacket_dispatcher *InstancePtr, const char* InstanceName);
int XPacket_dispatcher_Release(XPacket_dispatcher *InstancePtr);
#endif

void XPacket_dispatcher_Start(XPacket_dispatcher *InstancePtr);
u32 XPacket_dispatcher_IsDone(XPacket_dispatcher *InstancePtr);
u32 XPacket_dispatcher_IsIdle(XPacket_dispatcher *InstancePtr);
u32 XPacket_dispatcher_IsReady(XPacket_dispatcher *InstancePtr);
void XPacket_dispatcher_EnableAutoRestart(XPacket_dispatcher *InstancePtr);
void XPacket_dispatcher_DisableAutoRestart(XPacket_dispatcher *InstancePtr);


void XPacket_dispatcher_InterruptGlobalEnable(XPacket_dispatcher *InstancePtr);
void XPacket_dispatcher_InterruptGlobalDisable(XPacket_dispatcher *InstancePtr);
void XPacket_dispatcher_InterruptEnable(XPacket_dispatcher *InstancePtr, u32 Mask);
void XPacket_dispatcher_InterruptDisable(XPacket_dispatcher *InstancePtr, u32 Mask);
void XPacket_dispatcher_InterruptClear(XPacket_dispatcher *InstancePtr, u32 Mask);
u32 XPacket_dispatcher_InterruptGetEnabled(XPacket_dispatcher *InstancePtr);
u32 XPacket_dispatcher_InterruptGetStatus(XPacket_dispatcher *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
