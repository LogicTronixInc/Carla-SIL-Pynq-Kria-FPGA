// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xpacket_dispatcher.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XPacket_dispatcher_CfgInitialize(XPacket_dispatcher *InstancePtr, XPacket_dispatcher_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XPacket_dispatcher_Start(XPacket_dispatcher *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPacket_dispatcher_ReadReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_AP_CTRL) & 0x80;
    XPacket_dispatcher_WriteReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XPacket_dispatcher_IsDone(XPacket_dispatcher *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPacket_dispatcher_ReadReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XPacket_dispatcher_IsIdle(XPacket_dispatcher *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPacket_dispatcher_ReadReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XPacket_dispatcher_IsReady(XPacket_dispatcher *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XPacket_dispatcher_ReadReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XPacket_dispatcher_EnableAutoRestart(XPacket_dispatcher *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPacket_dispatcher_WriteReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XPacket_dispatcher_DisableAutoRestart(XPacket_dispatcher *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPacket_dispatcher_WriteReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_AP_CTRL, 0);
}

void XPacket_dispatcher_InterruptGlobalEnable(XPacket_dispatcher *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPacket_dispatcher_WriteReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_GIE, 1);
}

void XPacket_dispatcher_InterruptGlobalDisable(XPacket_dispatcher *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPacket_dispatcher_WriteReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_GIE, 0);
}

void XPacket_dispatcher_InterruptEnable(XPacket_dispatcher *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPacket_dispatcher_ReadReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_IER);
    XPacket_dispatcher_WriteReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_IER, Register | Mask);
}

void XPacket_dispatcher_InterruptDisable(XPacket_dispatcher *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XPacket_dispatcher_ReadReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_IER);
    XPacket_dispatcher_WriteReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_IER, Register & (~Mask));
}

void XPacket_dispatcher_InterruptClear(XPacket_dispatcher *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XPacket_dispatcher_WriteReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_ISR, Mask);
}

u32 XPacket_dispatcher_InterruptGetEnabled(XPacket_dispatcher *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPacket_dispatcher_ReadReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_IER);
}

u32 XPacket_dispatcher_InterruptGetStatus(XPacket_dispatcher *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XPacket_dispatcher_ReadReg(InstancePtr->Control_BaseAddress, XPACKET_DISPATCHER_CONTROL_ADDR_ISR);
}

