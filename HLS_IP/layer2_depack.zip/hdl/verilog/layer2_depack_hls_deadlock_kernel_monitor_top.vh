
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [5:0] axis_block_sigs;
wire [9:0] inst_idle_sigs;
wire [2:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~layer2_depack_header_parser_U0.pkt_in_TDATA_blk_n;
assign axis_block_sigs[1] = ~layer2_depack_header_parser_U0.grp_layer2_depack_header_parser_Pipeline_VITIS_LOOP_64_1_fu_89.pkt_in_TDATA_blk_n;
assign axis_block_sigs[2] = ~layer2_depack_fragment_tracker_U0.buffer_release_in_lidar_TDATA_blk_n;
assign axis_block_sigs[3] = ~layer2_depack_fragment_tracker_U0.grp_layer2_depack_fragment_tracker_Outline_VITIS_LOOP_323_3_fu_247.buffer_release_in_camera_TDATA_blk_n;
assign axis_block_sigs[4] = ~layer2_depack_fragment_tracker_U0.grp_TrackCameraFragment_fu_285.completion_out_camera_TDATA_blk_n;
assign axis_block_sigs[5] = ~layer2_depack_fragment_tracker_U0.grp_TrackLidarFragment_fu_324.completion_out_lidar_TDATA_blk_n;

assign inst_idle_sigs[0] = entry_proc_U0.ap_idle;
assign inst_block_sigs[0] = (entry_proc_U0.ap_done & ~entry_proc_U0.ap_continue) | ~entry_proc_U0.ddr_mem_lidar_c_blk_n | ~entry_proc_U0.ddr_mem_camera_c_blk_n;
assign inst_idle_sigs[1] = layer2_depack_header_parser_U0.ap_idle;
assign inst_block_sigs[1] = (layer2_depack_header_parser_U0.ap_done & ~layer2_depack_header_parser_U0.ap_continue) | ~layer2_depack_header_parser_U0.header_stream_blk_n | ~layer2_depack_header_parser_U0.grp_layer2_depack_header_parser_Pipeline_VITIS_LOOP_64_1_fu_89.payload_stream_blk_n;
assign inst_idle_sigs[2] = layer2_depack_fragment_tracker_U0.ap_idle;
assign inst_block_sigs[2] = (layer2_depack_fragment_tracker_U0.ap_done & ~layer2_depack_fragment_tracker_U0.ap_continue) | ~layer2_depack_fragment_tracker_U0.ddr_mem_lidar_blk_n | ~layer2_depack_fragment_tracker_U0.ddr_mem_camera_blk_n | ~layer2_depack_fragment_tracker_U0.header_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_layer2_depack_fragment_tracker_Pipeline_VITIS_LOOP_59_1_fu_279.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackCameraFragment_fu_285.grp_TrackCameraFragment_Pipeline_VITIS_LOOP_59_1_fu_421.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackCameraFragment_fu_285.grp_TrackCameraFragment_Pipeline_VITIS_LOOP_59_17_fu_427.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackCameraFragment_fu_285.grp_TrackCameraFragment_Pipeline_VITIS_LOOP_59_18_fu_433.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackCameraFragment_fu_285.grp_TrackCameraFragment_Pipeline_VITIS_LOOP_127_1_fu_439.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackCameraFragment_fu_285.grp_TrackCameraFragment_Pipeline_VITIS_LOOP_59_19_fu_449.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackLidarFragment_fu_324.grp_TrackLidarFragment_Pipeline_VITIS_LOOP_59_1_fu_421.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackLidarFragment_fu_324.grp_TrackLidarFragment_Pipeline_VITIS_LOOP_59_14_fu_427.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackLidarFragment_fu_324.grp_TrackLidarFragment_Pipeline_VITIS_LOOP_59_15_fu_433.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackLidarFragment_fu_324.grp_TrackLidarFragment_Pipeline_VITIS_LOOP_108_1_fu_439.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_TrackLidarFragment_fu_324.grp_TrackLidarFragment_Pipeline_VITIS_LOOP_59_16_fu_449.payload_stream_blk_n | ~layer2_depack_fragment_tracker_U0.grp_layer2_depack_fragment_tracker_Pipeline_VITIS_LOOP_59_13_fu_363.payload_stream_blk_n;

assign inst_idle_sigs[3] = 1'b0;
assign inst_idle_sigs[4] = layer2_depack_header_parser_U0.ap_idle;
assign inst_idle_sigs[5] = layer2_depack_header_parser_U0.grp_layer2_depack_header_parser_Pipeline_VITIS_LOOP_64_1_fu_89.ap_idle;
assign inst_idle_sigs[6] = layer2_depack_fragment_tracker_U0.ap_idle;
assign inst_idle_sigs[7] = layer2_depack_fragment_tracker_U0.grp_layer2_depack_fragment_tracker_Outline_VITIS_LOOP_323_3_fu_247.ap_idle;
assign inst_idle_sigs[8] = layer2_depack_fragment_tracker_U0.grp_TrackCameraFragment_fu_285.ap_idle;
assign inst_idle_sigs[9] = layer2_depack_fragment_tracker_U0.grp_TrackLidarFragment_fu_324.ap_idle;

layer2_depack_hls_deadlock_idx0_monitor layer2_depack_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
