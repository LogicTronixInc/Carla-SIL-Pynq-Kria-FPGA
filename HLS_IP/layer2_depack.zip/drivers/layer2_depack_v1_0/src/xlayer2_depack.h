// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XLAYER2_DEPACK_H
#define XLAYER2_DEPACK_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xlayer2_depack_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XLayer2_depack_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XLayer2_depack;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XLayer2_depack_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XLayer2_depack_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XLayer2_depack_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XLayer2_depack_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XLayer2_depack_Initialize(XLayer2_depack *InstancePtr, UINTPTR BaseAddress);
XLayer2_depack_Config* XLayer2_depack_LookupConfig(UINTPTR BaseAddress);
#else
int XLayer2_depack_Initialize(XLayer2_depack *InstancePtr, u16 DeviceId);
XLayer2_depack_Config* XLayer2_depack_LookupConfig(u16 DeviceId);
#endif
int XLayer2_depack_CfgInitialize(XLayer2_depack *InstancePtr, XLayer2_depack_Config *ConfigPtr);
#else
int XLayer2_depack_Initialize(XLayer2_depack *InstancePtr, const char* InstanceName);
int XLayer2_depack_Release(XLayer2_depack *InstancePtr);
#endif

void XLayer2_depack_Start(XLayer2_depack *InstancePtr);
u32 XLayer2_depack_IsDone(XLayer2_depack *InstancePtr);
u32 XLayer2_depack_IsIdle(XLayer2_depack *InstancePtr);
u32 XLayer2_depack_IsReady(XLayer2_depack *InstancePtr);
void XLayer2_depack_EnableAutoRestart(XLayer2_depack *InstancePtr);
void XLayer2_depack_DisableAutoRestart(XLayer2_depack *InstancePtr);

void XLayer2_depack_Set_ddr_mem_lidar(XLayer2_depack *InstancePtr, u64 Data);
u64 XLayer2_depack_Get_ddr_mem_lidar(XLayer2_depack *InstancePtr);
void XLayer2_depack_Set_ddr_mem_camera(XLayer2_depack *InstancePtr, u64 Data);
u64 XLayer2_depack_Get_ddr_mem_camera(XLayer2_depack *InstancePtr);

void XLayer2_depack_InterruptGlobalEnable(XLayer2_depack *InstancePtr);
void XLayer2_depack_InterruptGlobalDisable(XLayer2_depack *InstancePtr);
void XLayer2_depack_InterruptEnable(XLayer2_depack *InstancePtr, u32 Mask);
void XLayer2_depack_InterruptDisable(XLayer2_depack *InstancePtr, u32 Mask);
void XLayer2_depack_InterruptClear(XLayer2_depack *InstancePtr, u32 Mask);
u32 XLayer2_depack_InterruptGetEnabled(XLayer2_depack *InstancePtr);
u32 XLayer2_depack_InterruptGetStatus(XLayer2_depack *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
