// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xlayer2_depack.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XLayer2_depack_CfgInitialize(XLayer2_depack *InstancePtr, XLayer2_depack_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XLayer2_depack_Start(XLayer2_depack *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_AP_CTRL) & 0x80;
    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XLayer2_depack_IsDone(XLayer2_depack *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XLayer2_depack_IsIdle(XLayer2_depack *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XLayer2_depack_IsReady(XLayer2_depack *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XLayer2_depack_EnableAutoRestart(XLayer2_depack *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XLayer2_depack_DisableAutoRestart(XLayer2_depack *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_AP_CTRL, 0);
}

void XLayer2_depack_Set_ddr_mem_lidar(XLayer2_depack *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_DDR_MEM_LIDAR_DATA, (u32)(Data));
    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_DDR_MEM_LIDAR_DATA + 4, (u32)(Data >> 32));
}

u64 XLayer2_depack_Get_ddr_mem_lidar(XLayer2_depack *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_DDR_MEM_LIDAR_DATA);
    Data += (u64)XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_DDR_MEM_LIDAR_DATA + 4) << 32;
    return Data;
}

void XLayer2_depack_Set_ddr_mem_camera(XLayer2_depack *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_DDR_MEM_CAMERA_DATA, (u32)(Data));
    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_DDR_MEM_CAMERA_DATA + 4, (u32)(Data >> 32));
}

u64 XLayer2_depack_Get_ddr_mem_camera(XLayer2_depack *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_DDR_MEM_CAMERA_DATA);
    Data += (u64)XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_DDR_MEM_CAMERA_DATA + 4) << 32;
    return Data;
}

void XLayer2_depack_InterruptGlobalEnable(XLayer2_depack *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_GIE, 1);
}

void XLayer2_depack_InterruptGlobalDisable(XLayer2_depack *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_GIE, 0);
}

void XLayer2_depack_InterruptEnable(XLayer2_depack *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_IER);
    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_IER, Register | Mask);
}

void XLayer2_depack_InterruptDisable(XLayer2_depack *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_IER);
    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_IER, Register & (~Mask));
}

void XLayer2_depack_InterruptClear(XLayer2_depack *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XLayer2_depack_WriteReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_ISR, Mask);
}

u32 XLayer2_depack_InterruptGetEnabled(XLayer2_depack *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_IER);
}

u32 XLayer2_depack_InterruptGetStatus(XLayer2_depack *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XLayer2_depack_ReadReg(InstancePtr->Control_BaseAddress, XLAYER2_DEPACK_CONTROL_ADDR_ISR);
}

