
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [3:0] axis_block_sigs;
wire [7:0] inst_idle_sigs;
wire [2:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~udp_rx_reader_U0.pkt_in_TDATA_blk_n;
assign axis_block_sigs[1] = ~udp_rx_reader_U0.grp_udp_rx_reader_Pipeline_VITIS_LOOP_93_1_fu_144.pkt_in_TDATA_blk_n;
assign axis_block_sigs[2] = ~udp_rx_writer_U0.payload_out_TDATA_blk_n;
assign axis_block_sigs[3] = ~udp_rx_writer_U0.grp_udp_rx_writer_Pipeline_VITIS_LOOP_178_1_fu_118.payload_out_TDATA_blk_n;

assign inst_idle_sigs[0] = udp_rx_reader_U0.ap_idle;
assign inst_block_sigs[0] = (udp_rx_reader_U0.ap_done & ~udp_rx_reader_U0.ap_continue) | ~udp_rx_reader_U0.meta_stream_blk_n | ~udp_rx_reader_U0.basic_ok_stream_blk_n | ~udp_rx_reader_U0.udp_csum_disabled_stream_blk_n | ~udp_rx_reader_U0.csum_stream_blk_n | ~udp_rx_reader_U0.grp_udp_rx_reader_Pipeline_VITIS_LOOP_93_1_fu_144.csum_stream_blk_n | ~udp_rx_reader_U0.grp_udp_rx_reader_Pipeline_VITIS_LOOP_93_1_fu_144.payload_buf_blk_n;
assign inst_idle_sigs[1] = udp_rx_csum_engine_U0.ap_idle;
assign inst_block_sigs[1] = (udp_rx_csum_engine_U0.ap_done & ~udp_rx_csum_engine_U0.ap_continue) | ~udp_rx_csum_engine_U0.csum_stream_blk_n | ~udp_rx_csum_engine_U0.udp_csum_ok_stream_blk_n;
assign inst_idle_sigs[2] = udp_rx_writer_U0.ap_idle;
assign inst_block_sigs[2] = (udp_rx_writer_U0.ap_done & ~udp_rx_writer_U0.ap_continue) | ~udp_rx_writer_U0.meta_stream_blk_n | ~udp_rx_writer_U0.basic_ok_stream_blk_n | ~udp_rx_writer_U0.udp_csum_disabled_stream_blk_n | ~udp_rx_writer_U0.udp_csum_ok_stream_blk_n | ~udp_rx_writer_U0.grp_udp_rx_writer_Pipeline_VITIS_LOOP_178_1_fu_118.payload_buf_blk_n;

assign inst_idle_sigs[3] = 1'b0;
assign inst_idle_sigs[4] = udp_rx_reader_U0.ap_idle;
assign inst_idle_sigs[5] = udp_rx_reader_U0.grp_udp_rx_reader_Pipeline_VITIS_LOOP_93_1_fu_144.ap_idle;
assign inst_idle_sigs[6] = udp_rx_writer_U0.ap_idle;
assign inst_idle_sigs[7] = udp_rx_writer_U0.grp_udp_rx_writer_Pipeline_VITIS_LOOP_178_1_fu_118.ap_idle;

udp_rx_hls_deadlock_idx0_monitor udp_rx_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
