// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xlayer1_camera_prep.h"

extern XLayer1_camera_prep_Config XLayer1_camera_prep_ConfigTable[];

#ifdef SDT
XLayer1_camera_prep_Config *XLayer1_camera_prep_LookupConfig(UINTPTR BaseAddress) {
	XLayer1_camera_prep_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XLayer1_camera_prep_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XLayer1_camera_prep_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XLayer1_camera_prep_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XLayer1_camera_prep_Initialize(XLayer1_camera_prep *InstancePtr, UINTPTR BaseAddress) {
	XLayer1_camera_prep_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XLayer1_camera_prep_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XLayer1_camera_prep_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XLayer1_camera_prep_Config *XLayer1_camera_prep_LookupConfig(u16 DeviceId) {
	XLayer1_camera_prep_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XLAYER1_CAMERA_PREP_NUM_INSTANCES; Index++) {
		if (XLayer1_camera_prep_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XLayer1_camera_prep_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XLayer1_camera_prep_Initialize(XLayer1_camera_prep *InstancePtr, u16 DeviceId) {
	XLayer1_camera_prep_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XLayer1_camera_prep_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XLayer1_camera_prep_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

