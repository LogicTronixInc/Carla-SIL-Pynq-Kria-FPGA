// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XLAYER1_CAMERA_PREP_H
#define XLAYER1_CAMERA_PREP_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xlayer1_camera_prep_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XLayer1_camera_prep_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XLayer1_camera_prep;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XLayer1_camera_prep_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XLayer1_camera_prep_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XLayer1_camera_prep_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XLayer1_camera_prep_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XLayer1_camera_prep_Initialize(XLayer1_camera_prep *InstancePtr, UINTPTR BaseAddress);
XLayer1_camera_prep_Config* XLayer1_camera_prep_LookupConfig(UINTPTR BaseAddress);
#else
int XLayer1_camera_prep_Initialize(XLayer1_camera_prep *InstancePtr, u16 DeviceId);
XLayer1_camera_prep_Config* XLayer1_camera_prep_LookupConfig(u16 DeviceId);
#endif
int XLayer1_camera_prep_CfgInitialize(XLayer1_camera_prep *InstancePtr, XLayer1_camera_prep_Config *ConfigPtr);
#else
int XLayer1_camera_prep_Initialize(XLayer1_camera_prep *InstancePtr, const char* InstanceName);
int XLayer1_camera_prep_Release(XLayer1_camera_prep *InstancePtr);
#endif

void XLayer1_camera_prep_Start(XLayer1_camera_prep *InstancePtr);
u32 XLayer1_camera_prep_IsDone(XLayer1_camera_prep *InstancePtr);
u32 XLayer1_camera_prep_IsIdle(XLayer1_camera_prep *InstancePtr);
u32 XLayer1_camera_prep_IsReady(XLayer1_camera_prep *InstancePtr);
void XLayer1_camera_prep_EnableAutoRestart(XLayer1_camera_prep *InstancePtr);
void XLayer1_camera_prep_DisableAutoRestart(XLayer1_camera_prep *InstancePtr);

void XLayer1_camera_prep_Set_ddr_mem(XLayer1_camera_prep *InstancePtr, u64 Data);
u64 XLayer1_camera_prep_Get_ddr_mem(XLayer1_camera_prep *InstancePtr);

void XLayer1_camera_prep_InterruptGlobalEnable(XLayer1_camera_prep *InstancePtr);
void XLayer1_camera_prep_InterruptGlobalDisable(XLayer1_camera_prep *InstancePtr);
void XLayer1_camera_prep_InterruptEnable(XLayer1_camera_prep *InstancePtr, u32 Mask);
void XLayer1_camera_prep_InterruptDisable(XLayer1_camera_prep *InstancePtr, u32 Mask);
void XLayer1_camera_prep_InterruptClear(XLayer1_camera_prep *InstancePtr, u32 Mask);
u32 XLayer1_camera_prep_InterruptGetEnabled(XLayer1_camera_prep *InstancePtr);
u32 XLayer1_camera_prep_InterruptGetStatus(XLayer1_camera_prep *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
